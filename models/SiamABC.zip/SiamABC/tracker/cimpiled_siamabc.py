"""
TRTSiamABCNet
=============
Drop-in TensorRT replacement for SiamABCNet for use inside SiamABCTracker.

Architecture
------------
get_features      → fully TRT-compiled (encoder + neck)

track             → SPLIT into two stages:
  Stage 1 (TRT)  : polarized_self_attention + attention_neck
                   (two engines: one per spatial resolution)
  Stage 2 (torch.compile, FP32) : connect_model  (BoxTower + AdaptiveBatchNorm)
                   AdaptiveBatchNorm has Python-level control flow that TRT's
                   dynamo tracer cannot lower; torch.compile handles it fine.
                   IMPORTANT: connect_model is kept in FP32 to preserve the
                   classification score precision that all SiamRAMTracker
                   thresholds (conf_threshold, reacq_threshold, etc.) depend on.

Why not cast connect_model to FP16?
  The cls_pred sigmoid output feeds hard thresholds (0.55, 0.70, 0.80) in
  SiamRAMTracker. FP16 reduces pre-sigmoid logit precision near 0, causing
  borderline-good scores (~0.56) to round below threshold, triggering spurious
  occlusion entry every frame and halving tracking performance. The encoder/neck
  (the bulk of compute) still runs in FP16 for speed.

Delegated / no-op:
    modules()                   → original model (AdaptiveBatchNorm discovery)
    invalidate_template_cache() → no-op (TRT engines are stateless)
"""

from __future__ import annotations

import copy
import logging
from typing import Dict, Optional, Set, Tuple

import torch
import torch.nn as nn
import torch_tensorrt

from ..model import constants

log = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# nn.Module wrappers — pure tensor I/O, safe for TRT tracing                  #
# --------------------------------------------------------------------------- #

class _FeatureExtractorModule(nn.Module):
    """encoder + neck  (deep-copied, dtype-isolated)."""

    def __init__(self, net: nn.Module) -> None:
        super().__init__()
        self.encoder = copy.deepcopy(net.encoder)
        self.neck    = copy.deepcopy(net.neck)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.neck(self.encoder(x))


class _AttentionModule(nn.Module):
    """
    polarized_self_attention + attention_neck for ONE branch.

    Called twice per track step (template branch, search branch).
    We compile a single engine and call it for both — the weights are shared
    so this is correct.

    Input : (B, 2*C, h, w)   — concatenated feature pair
    Output: (B, C,   h, w)   — mixed attention features
    """

    def __init__(self, net: nn.Module) -> None:
        super().__init__()
        self.polarized_self_attention = copy.deepcopy(net.polarized_self_attention)
        self.attention_neck           = copy.deepcopy(net.attention_neck)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.attention_neck(self.polarized_self_attention(x))


class _ConnectModel(nn.Module):
    """
    Thin wrapper around BoxTower / connect_model.
    Deep-copied and compiled with torch.compile (not TRT) because
    AdaptiveBatchNorm contains Python-level control flow over `lam`.

    Always runs in FP32 — do NOT cast this module to FP16.
    """

    def __init__(self, net: nn.Module) -> None:
        super().__init__()
        self.connect_model = copy.deepcopy(net.connect_model)

    def forward(
        self,
        search_org: torch.Tensor,
        search:     torch.Tensor,
        kernel:     torch.Tensor,
        lam:        float,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        bbox_pred, cls_pred, _, _ = self.connect_model(
            search_org=search_org,
            search=search,
            kernel=kernel,
            lam=lam,
        )
        return bbox_pred, cls_pred


# --------------------------------------------------------------------------- #
# Helpers                                                                      #
# --------------------------------------------------------------------------- #

def _cast_module(module: nn.Module, dtype: torch.dtype) -> nn.Module:
    """Cast all params/buffers of *module* to *dtype* in-place and return it."""
    return module.half() if dtype == torch.float16 else module.float()


def _trt_input(
    shape:     Tuple[int, ...],
    min_batch: int,
    opt_batch: int,
    max_batch: int,
    dtype:     torch.dtype,
) -> torch_tensorrt.Input:
    _b, *rest = shape
    return torch_tensorrt.Input(
        min_shape=(min_batch, *rest),
        opt_shape=(opt_batch, *rest),
        max_shape=(max_batch, *rest),
        dtype=dtype,
    )


# --------------------------------------------------------------------------- #
# Public wrapper                                                               #
# --------------------------------------------------------------------------- #

class TRTSiamABCNet:
    """
    TensorRT + torch.compile wrapper for SiamABCNet.

    Parameters
    ----------
    model        : trained SiamABCNet — already .cuda().eval(), kept in FP32
    template_size: spatial H/W of template crop (e.g. 64)
    instance_size: spatial H/W of search  crop  (e.g. 128)
    norm_lambda  : TTA blending weight
    cuda_id      : GPU index
    fp16         : use FP16 for TRT engines (encoder/neck/attention ONLY —
                   connect_model is always kept FP32 for score precision)
    min/opt/max_batch: TRT dynamic-shape batch-size range (1/1/1 for tracking)
    """

    def __init__(
        self,
        model:         nn.Module,
        template_size: int,
        instance_size: int,
        norm_lambda:   float = 0.1,
        cuda_id:       int   = 0,
        fp16:          bool  = True,
        min_batch:     int   = 1,
        opt_batch:     int   = 1,
        max_batch:     int   = 1,
    ) -> None:

        self._model         = model.eval()   # original FP32 — never mutated
        self._norm_lambda   = norm_lambda
        self._device        = torch.device(f"cuda:{cuda_id}")
        self._fp16          = fp16
        self._dtype         = torch.float16 if fp16 else torch.float32
        self._template_size = template_size
        self._instance_size = instance_size

        enabled_precisions: Set[torch.dtype] = (
            {torch.float16} if fp16 else {torch.float32}
        )
        batch = (min_batch, opt_batch, max_batch)

        # ------------------------------------------------------------------ #
        # Step 0 — probe shapes on original FP32 model                        #
        # ------------------------------------------------------------------ #
        log.info("TRTSiamABCNet: probing feature-map shapes…")
        with torch.no_grad():
            _t = torch.randn(opt_batch, 3, template_size, template_size,
                             device=self._device, dtype=torch.float32)
            _s = torch.randn(opt_batch, 3, instance_size, instance_size,
                             device=self._device, dtype=torch.float32)
            t_feat_shape: Tuple[int, ...] = tuple(model.get_features(_t).shape)
            s_feat_shape: Tuple[int, ...] = tuple(model.get_features(_s).shape)

        _, C, h_t, w_t = t_feat_shape
        _, _,  h_s, w_s = s_feat_shape
        t_attn_in_shape = (opt_batch, 2 * C, h_t, w_t)
        s_attn_in_shape = (opt_batch, 2 * C, h_s, w_s)

        log.info(
            "TRTSiamABCNet: template-feat %s  search-feat %s",
            t_feat_shape, s_feat_shape,
        )

        # ------------------------------------------------------------------ #
        # Step 1 — TRT: get_features (encoder + neck) — runs in fp16          #
        # ------------------------------------------------------------------ #
        log.info("TRTSiamABCNet: compiling get_features engines…")

        self._trt_feat_template = self._compile_feat(
            model, template_size, *batch, enabled_precisions,
        )
        self._trt_feat_search = self._compile_feat(
            model, instance_size, *batch, enabled_precisions,
        )
        log.info("TRTSiamABCNet: get_features engines ready.")

        # ------------------------------------------------------------------ #
        # Step 2 — TRT: attention engines — runs in fp16                       #
        # ------------------------------------------------------------------ #
        log.info("TRTSiamABCNet: compiling attention engines…")

        self._trt_attn_template = self._compile_attention(
            model, t_attn_in_shape, *batch, enabled_precisions,
        )
        if (h_t, w_t) == (h_s, w_s):
            self._trt_attn_search = self._trt_attn_template
            log.info("TRTSiamABCNet: template and search share the same attention engine.")
        else:
            self._trt_attn_search = self._compile_attention(
                model, s_attn_in_shape, *batch, enabled_precisions,
            )
        log.info("TRTSiamABCNet: attention engines ready.")

        # ------------------------------------------------------------------ #
        # Step 3 — torch.compile: connect_model — ALWAYS FP32                 #
        #                                                                      #
        # DO NOT cast this to fp16. The cls_pred output is passed through      #
        # sigmoid and compared against hard thresholds (0.55, 0.70, 0.80) in  #
        # SiamRAMTracker. FP16 precision loss near sigmoid(0) causes scores    #
        # that should be 0.56 to become 0.54, triggering spurious occlusion   #
        # entry on every frame and destroying tracking performance.            #
        # ------------------------------------------------------------------ #
        log.info("TRTSiamABCNet: compiling connect_model with torch.compile (FP32)…")

        connect_mod = (
            _ConnectModel(model)
            .eval()
            .to(self._device)
            # intentionally NOT cast to fp16 — must stay fp32
        )

        self._connect_model = torch.compile(connect_mod, mode="default")

        # Pre-warm torch.compile with both lam=0 and lam=norm_lambda traces
        self._warm_connect_model(s_feat_shape, t_feat_shape, norm_lambda)

        log.info("TRTSiamABCNet: connect_model compiled and warmed up. All ready.")


    
    def _warm_connect_model(self, s_feat_shape, t_feat_shape, norm_lambda):
        with torch.no_grad():
            _, C_s, h_s, w_s = s_feat_shape
            _, C_t, h_t, w_t = t_feat_shape

            # Always fp32 — matches what connect_model actually receives at runtime
            dummy_search_org = torch.randn(1, C_s, h_s, w_s,
                                        device=self._device, dtype=torch.float32)
            dummy_search     = torch.randn(1, C_s, h_s, w_s,
                                        device=self._device, dtype=torch.float32)
            dummy_kernel     = torch.randn(1, C_t, h_t, w_t,
                                        device=self._device, dtype=torch.float32)

            for lam_val in (0.0, norm_lambda):
                self._connect_model(
                    search_org=dummy_search_org,
                    search=dummy_search,
                    kernel=dummy_kernel,
                    lam=lam_val,
                )    # ------------------------------------------------------------------ #
    # Compilation helpers                                                  #
    # ------------------------------------------------------------------ #

    def _compile_feat(
        self,
        model:              nn.Module,
        crop_size:          int,
        min_batch:          int,
        opt_batch:          int,
        max_batch:          int,
        enabled_precisions: Set[torch.dtype],
    ):
        mod = _FeatureExtractorModule(model).eval().to(self._device)
        _cast_module(mod, self._dtype)

        return torch_tensorrt.compile(
            mod,
            inputs=[
                _trt_input(
                    (1, 3, crop_size, crop_size),
                    min_batch, opt_batch, max_batch,
                    self._dtype,
                )
            ],
            enabled_precisions=enabled_precisions,
            truncate_long_and_double=True,
        )

    def _compile_attention(
        self,
        model:              nn.Module,
        attn_in_shape:      Tuple[int, ...],
        min_batch:          int,
        opt_batch:          int,
        max_batch:          int,
        enabled_precisions: Set[torch.dtype],
    ):
        # --- FIX 2: attention engines always run in FP32 -------------------------
        # Template and search branches are compiled as separate TRT engines with
        # different spatial sizes.  TRT picks different FP16 fusion paths per shape,
        # making t_mixed and s_mixed land in incompatible numeric sub-spaces.
        # Forcing FP32 here makes the two engines numerically consistent so that
        # the cross-correlation in BoxTower works as intended.
        mod = _AttentionModule(model).eval().to(self._device).float()  # keep FP32

        attn_input_dtype = torch.float32   # always FP32 for attention

        return torch_tensorrt.compile(
            mod,
            inputs=[
                _trt_input(attn_in_shape, min_batch, opt_batch, max_batch,
                        attn_input_dtype)          # ← FP32 input
            ],
            enabled_precisions={torch.float32},       # ← FP32 engine
            truncate_long_and_double=True,
        )
        # ------------------------------------------------------------------ #
    # Interface expected by SiamABCTracker                                #
    # ------------------------------------------------------------------ #

    def get_features(self, crop: torch.Tensor) -> torch.Tensor:
        """
        Mirrors SiamABCNet.get_features(crop).
        Dispatches by spatial size. Always returns float32.
        """
        _b, _c, h, _w = crop.shape
        crop = crop.to(dtype=self._dtype, device=self._device)

        if h == self._template_size:
            out = self._trt_feat_template(crop)
        elif h == self._instance_size:
            out = self._trt_feat_search(crop)
        else:
            raise ValueError(
                f"get_features: unexpected crop height {h}. "
                f"Expected {self._template_size} (template) or "
                f"{self._instance_size} (search)."
            )
        # Always return fp32 so downstream code (including connect_model) works correctly
        return out.float().contiguous()

    def track(
    self,
    search_features:           torch.Tensor,
    dynamic_search_features:   torch.Tensor,
    template_features:         torch.Tensor,
    dynamic_template_features: torch.Tensor,
    lam:                       torch.Tensor,
) -> Dict[str, Optional[torch.Tensor]]:

        def _cast(t: torch.Tensor) -> torch.Tensor:
            return t.to(dtype=self._dtype, device=self._device)

        sf  = _cast(search_features)
        dsf = _cast(dynamic_search_features)
        tf  = _cast(template_features)
        dtf = _cast(dynamic_template_features)

        t_combined = torch.cat([tf.float(),  dtf.float()], dim=1)
        s_combined = torch.cat([dsf.float(), sf.float()],  dim=1)

        # .contiguous() forces NCHW layout — TRT outputs can be channel-last
        # which silently corrupts CUDA-graph-compiled or conv-based modules
        t_mixed = self._trt_attn_template(t_combined).contiguous()
        s_mixed = self._trt_attn_search(s_combined).contiguous()

        # All inputs to the FP32 connect_model must be FP32
        bbox_pred, cls_pred = self._connect_model(
            search_org=sf.float().contiguous(),
            search=s_mixed.float(),
            kernel=t_mixed.float(),
            lam=float(lam.item()),
        )

        return {
            constants.TARGET_REGRESSION_LABEL_KEY:     bbox_pred.float(),
            constants.TARGET_CLASSIFICATION_KEY:       cls_pred.float(),
            constants.TRACKER_TARGET_SEARCH_SIM_SCORE: None,
            constants.TRACKER_ATTENTION_MAP:           s_mixed.float(),
        }
    def modules(self):
        """Delegated to the original FP32 model for AdaptiveBatchNorm discovery."""
        return self._model.modules()

    def invalidate_template_cache(self) -> None:
        """No-op — TRT engines are stateless."""


# --------------------------------------------------------------------------- #
# Factory                                                                      #
# --------------------------------------------------------------------------- #

def get_trt_tracker(
    config,
    weights_path: str,
    lambda_tta:   float = 0.1,
    fp16:         bool  = True,
    cuda_id:      int   = 0,
):
    """
    Drop-in replacement for get_tracker() that returns a TRT-compiled tracker.

    Example
    -------
        tracker = get_trt_tracker(config, "weights/model.pth",
                                  lambda_tta=0.1, fp16=True)
    """
    from hydra.utils import instantiate
    from pytorch_toolbelt.utils import transfer_weights

    from .SiamABC_Tracker import SiamABCTracker  # noqa: F401

    model: nn.Module = instantiate(
        config["model"], inference_mode=True, norm_lambda=lambda_tta
    )
    checkpoint = torch.load(weights_path, map_location=f"cuda:{cuda_id}")
    state_dict = {
        k.lstrip("module").lstrip("."): v
        for k, v in checkpoint.items()
        if k.startswith("module.")
    }
    transfer_weights(model, state_dict)
    model = model.to(f"cuda:{cuda_id}").eval()

    tracking_cfg  = config["tracker"]
    template_size = int(tracking_cfg["template_size"])
    instance_size = int(tracking_cfg["instance_size"])

    trt_model = TRTSiamABCNet(
        model=model,
        template_size=template_size,
        instance_size=instance_size,
        norm_lambda=lambda_tta,
        cuda_id=cuda_id,
        fp16=fp16,
    )

    # ---- 4. Instantiate tracker --------------------------------------------
    tracker: SiamABCTracker = instantiate(config["tracker"], model=trt_model)
    return tracker